# หน่วยที่ 3: ฐานข้อมูลด้วย MongoDB
## บทเรียนย่อย: Schema Design & Relations

### 🏗️ การออกแบบ Schema ที่ดี

          การออกแบบ Schema ที่ดีจะส่งผลต่อประสิทธิภาพและความยืดหยุ่นของระบบ

          ### 🔗 Relations — Populate

          ```javascript
// Order อ้างอิงถึง User
const orderSchema = new mongoose.Schema({
  user: { type: mongoose.Schema.Types.ObjectId, ref: 'User' },
  totalPrice: Number
});

// ดึงข้อมูลพร้อม populate เพื่อดึงชื่อผู้ใช้
const order = await Order.findById(id).populate('user', 'name email');
```

          ### 📊 Aggregation Pipeline (ขั้นสูง)

          เมื่อต้องการประมวลผลข้อมูลซับซ้อน เช่น การหายอดขายรวมต่อเดือน

          ```javascript
const salesReport = await Order.aggregate([
  { $match: { status: 'completed' } },
  { 
    $group: {
      _id: { $month: "$createdAt" },
      totalRevenue: { $sum: "$totalPrice" },
      count: { $sum: 1 }
    }
  },
  { $sort: { _id: 1 } }
]);
```

          ### 📌 Indexing — เพิ่มความเร็ว

          ```javascript
// สร้าง index เพื่อค้นหาได้เร็วขึ้น
userSchema.index({ email: 1 });           // single
productSchema.index({ name: 1, price: -1 }); // compound
productSchema.index({ name: 'text' });     // text search
```
