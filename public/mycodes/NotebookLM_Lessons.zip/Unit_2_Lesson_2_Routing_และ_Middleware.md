# หน่วยที่ 2: Node.js และ Express
## บทเรียนย่อย: Routing และ Middleware

### 🗺️ Express Routing & MVC

          ในการทำงานจริง เรามักจะจัดโครงสร้างแบบ MVC (Model-View-Controller) เพื่อให้โค้ดเป็นระเบียบ

          ```javascript
// 📂 controllers/userController.js
exports.getUsers = (req, res) => {
  res.json({ users: [{ id: 1, name: 'Alice' }] });
};

exports.createUser = (req, res) => {
  const { name, email } = req.body;
  res.status(201).json({ id: 2, name, email });
};
```

          ```javascript
// 📂 routes/userRoutes.js
const express = require('express');
const router = express.Router();
const userController = require('../controllers/userController');

router.get('/', userController.getUsers);
router.post('/', userController.createUser);

module.exports = router;
```

          ### 🔧 Middleware

          Middleware คือฟังก์ชันที่ทำงานคั่นกลางระหว่าง Request และ Controller

          ```javascript
// Logging middleware
const logger = (req, res, next) => {
  console.log(`[${new Date().toISOString()}] ${req.method} ${req.path}`);
  next(); // ส่งต่อไปยัง middleware หรือ controller ถัดไป
};

app.use(logger);
```
