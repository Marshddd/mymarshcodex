# หน่วยที่ 4: Authentication & JWT
## บทเรียนย่อย: JWT Authentication

### 🔐 JSON Web Token (JWT)

          JWT คือมาตรฐานสำหรับการส่ง claim ระหว่าง parties อย่างปลอดภัย ประกอบด้วย 3 ส่วน:

          

            - **Header:** ระบุ algorithm ที่ใช้

            - **Payload:** ข้อมูล user

            - **Signature:** ลายเซ็นยืนยัน

          

          ```
`npm install jsonwebtoken bcryptjs`
```

          ### 🔑 สร้างและยืนยัน Token

          ```javascript
const jwt = require('jsonwebtoken');
const bcrypt = require('bcryptjs');

// Register
const hashedPassword = await bcrypt.hash(password, 10);

// Login
const isValid = await bcrypt.compare(password, hashedPassword);
const token = jwt.sign(
  { userId: user._id },
  process.env.JWT_SECRET,
  { expiresIn: '7d' }
);

// Verify
const decoded = jwt.verify(token, process.env.JWT_SECRET);
```
