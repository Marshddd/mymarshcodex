# หน่วยที่ 6: Cloud Deployment (AWS)
## บทเรียนย่อย: CI/CD Pipeline

### 🔄 CI/CD คืออะไร?

          **CI (Continuous Integration)** — รวมโค้ด, ทดสอบ, build อัตโนมัติ

          **CD (Continuous Deployment)** — deploy ขึ้น production อัตโนมัติ

          ### 📝 GitHub Actions

          ```javascript
# .github/workflows/deploy.yml
name: Deploy to EC2

on:
  push:
    branches: [main]

jobs:
  test:
    runs-on: ubuntu-latest
    steps:
      - uses: actions/checkout@v4
      - uses: actions/setup-node@v4
        with:
          node-version: 20
      - run: npm ci
      - run: npm test

  deploy:
    needs: test
    runs-on: ubuntu-latest
    steps:
      - uses: actions/checkout@v4
      - name: Deploy to EC2
        uses: appleboy/ssh-action@v1
        with:
          host: ${{ secrets.EC2_HOST }}
          username: ec2-user
          key: ${{ secrets.EC2_KEY }}
          script: |
            cd /app/my-api
            git pull origin main
            npm ci --production
            pm2 restart my-api
```

          ### 🐳 Docker + CI/CD

          ```javascript
# Build และ Push Docker image ไป ECR
- name: Build Docker Image
  run: docker build -t my-api:latest .

- name: Push to ECR
  run: |
    aws ecr get-login-password | docker login --username AWS --password-stdin $ECR_REGISTRY
    docker tag my-api:latest $ECR_REGISTRY/my-api:latest
    docker push $ECR_REGISTRY/my-api:latest
```

          ### ✅ สรุป Flow

          ```javascript
Developer Push Code
      ↓
GitHub Actions Triggered
      ↓
Run Tests (npm test)
      ↓
Build Docker Image
      ↓
Push to Registry (ECR)
      ↓
Deploy to EC2/ECS
      ↓
🎉 Live on Production!
```
