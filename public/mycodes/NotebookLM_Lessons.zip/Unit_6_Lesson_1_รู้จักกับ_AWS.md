# หน่วยที่ 6: Cloud Deployment (AWS)
## บทเรียนย่อย: รู้จักกับ AWS

### ☁️ Amazon Web Services (AWS)

          AWS เป็น Cloud Platform ที่ใหญ่ที่สุดในโลก มีบริการมากกว่า 200 รายการ

          ### 🧱 บริการหลักที่ใช้บ่อย

          

            - **EC2:** Virtual Server — เครื่อง server ในคลาวด์

            - **S3:** Object Storage — เก็บไฟล์, รูปภาพ, backup

            - **RDS:** Managed Database — ฐานข้อมูลที่จัดการให้

            - **Lambda:** Serverless Functions — รันโค้ดโดยไม่ต้องจัดการ server

            - **ECS/EKS:** Container Services — รัน Docker containers

            - **CloudFront:** CDN — กระจาย content ทั่วโลก

          

          ### 🔑 AWS CLI

          ```javascript
# ติดตั้ง AWS CLI
pip install awscli

# ตั้งค่า credentials
aws configure
# AWS Access Key ID: AKIA...
# AWS Secret Access Key: xxxxx
# Default region: ap-southeast-1
# Default output format: json
```

          ### 💰 ค่าใช้จ่าย

          AWS มี Free Tier สำหรับผู้เริ่มต้น 12 เดือนแรก:

          

            - EC2: t2.micro 750 ชม./เดือน

            - S3: 5 GB storage

            - RDS: t2.micro 750 ชม./เดือน

            - Lambda: 1 ล้าน requests/เดือน
