# หน่วยที่ 5: Docker & Containerization
## บทเรียนย่อย: Docker คืออะไร?

### 🐳 Docker คืออะไร?

          Docker คือแพลตฟอร์มสำหรับสร้าง, ทดสอบ และ deploy แอปพลิเคชันในรูปแบบ Container ที่แยกเป็นหน่วยอิสระ

          ### 📦 Container vs Virtual Machine

          

            - **Container:** เบา, เร็ว, แชร์ OS Kernel — เริ่มต้นภายในวินาที

            - **VM:** หนัก, ช้ากว่า, มี OS แยกของตัวเอง — ใช้เวลานาทีในการเริ่ม

          

          ### 🧩 คำศัพท์สำคัญ

          

            - `Image` — เทมเพลตที่ใช้สร้าง Container (เหมือนแบบบ้าน)

            - `Container` — instance ที่รันจาก Image (เหมือนตัวบ้านจริง)

            - `Dockerfile` — สคริปต์สำหรับสร้าง Image

            - `Registry` — ที่เก็บ Images (เช่น Docker Hub)

          

          ### ⚡ คำสั่งพื้นฐาน

          ```javascript
# ดาวน์โหลด image
docker pull node:20-alpine

# ดู images ทั้งหมด
docker images

# รัน container
docker run -d -p 3000:3000 --name myapp node:20

# ดู containers ที่กำลังทำงาน
docker ps

# หยุด container
docker stop myapp

# ลบ container
docker rm myapp
```
