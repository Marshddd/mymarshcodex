# หน่วยที่ 1: พื้นฐาน Back-End
## บทเรียนย่อย: Client-Server Architecture

### 🏗️ สถาปัตยกรรม Client-Server

          ในการพัฒนาเว็บ การสื่อสารจะเกิดขึ้นระหว่าง 2 ฝ่าย:

          

            - **Client (Front-End):** เบราว์เซอร์, มือถือ, แอปต่างๆ ที่ผู้ใช้โต้ตอบ

            - **Server (Back-End):** เครื่องแม่ข่ายที่ประมวลผลและส่งข้อมูลกลับ

          

          ### 🔁 ขั้นตอนการทำงาน

          ```javascript
1. Client ส่ง HTTP Request ไปที่ Server
2. Server รับ request และประมวลผล
3. Server อาจดึงข้อมูลจาก Database
4. Server ส่ง HTTP Response กลับไป
5. Client แสดงผลข้อมูลให้ผู้ใช้
```

          ### 🔒 Request vs Response

          **Request** ประกอบด้วย:

          

            - Method (GET, POST, etc.)

            - URL / Endpoint

            - Headers (metadata)

            - Body (ข้อมูลที่ส่งมา)

          

          **Response** ประกอบด้วย:

          

            - Status Code (200, 404, etc.)

            - Headers

            - Body (ข้อมูลที่ส่งกลับ)

          

          ### 📦 ตัวอย่าง JSON Response

          ```javascript
{
  "status": "success",
  "data": {
    "id": 1,
    "name": "สมชาย",
    "email": "somchai@example.com"
  }
}
```
