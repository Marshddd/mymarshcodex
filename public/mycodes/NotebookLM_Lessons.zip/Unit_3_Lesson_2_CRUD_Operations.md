# หน่วยที่ 3: ฐานข้อมูลด้วย MongoDB
## บทเรียนย่อย: CRUD Operations

### 📝 CRUD คืออะไร?

          CRUD ย่อมาจาก Create, Read, Update, Delete — เป็นการดำเนินการพื้นฐานกับข้อมูล

          ### ➕ Create — สร้างข้อมูล

          ```javascript
// สร้างผู้ใช้ใหม่
const newUser = new User({
  name: 'สมชาย',
  email: 'somchai@email.com',
  password: 'hashed_password'
});
await newUser.save();

// หรือใช้ create()
const user = await User.create({
  name: 'สมหญิง',
  email: 'somying@email.com'
});
```

          ### 📖 Read — อ่านข้อมูล

          ```javascript
// ดึงทั้งหมด
const users = await User.find();

// ดึงตามเงื่อนไข
const admins = await User.find({ role: 'admin' });

// ดึงคนเดียว
const user = await User.findById(id);
const user2 = await User.findOne({ email: 'test@email.com' });
```

          ### ✏️ Update — อัปเดตข้อมูล

          ```javascript
await User.findByIdAndUpdate(id, {
  name: 'ชื่อใหม่'
}, { new: true }); // new: true คืนค่าที่อัปเดตแล้ว
```

          ### 🗑️ Delete — ลบข้อมูล

          ```javascript
await User.findByIdAndDelete(id);

// ลบหลายรายการ
await User.deleteMany({ role: 'inactive' });
```
