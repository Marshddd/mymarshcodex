# หน่วยที่ 2: Node.js และ Express
## บทเรียนย่อย: ติดตั้ง Node.js และ Express

### 📦 การติดตั้ง Node.js

          ดาวน์โหลด Node.js จาก `nodejs.org` และทำการติดตั้ง หลังจากนั้นตรวจสอบด้วยคำสั่ง:

          ```javascript
node --version   # v20.x.x
npm --version    # 10.x.x
```

          ### 🚀 สร้างโปรเจค Express

          ```javascript
mkdir my-server
cd my-server
npm init -y
npm install express
```

          ### 💻 Server แรกของเรา

          ```javascript
// server.js
const express = require('express');
const app = express();

app.use(express.json());

app.get('/', (req, res) => {
  res.json({ message: 'สวัสดี Backend! 🚀' });
});

app.listen(3000, () => {
  console.log('Server กำลังทำงานที่ port 3000');
});
```

          ### ▶️ รัน Server

          ```
`node server.js`
```

          เปิด browser ไปที่ `http://localhost:3000` จะเห็น JSON response ของเรา!
