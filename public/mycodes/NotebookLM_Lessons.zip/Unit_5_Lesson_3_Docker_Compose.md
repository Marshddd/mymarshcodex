# หน่วยที่ 5: Docker & Containerization
## บทเรียนย่อย: Docker Compose

### 🎼 Docker Compose คืออะไร?

          Docker Compose ใช้สำหรับจัดการ multi-container application — เช่น app + database + cache ในคำสั่งเดียว

          ### 📝 docker-compose.yml

          ```javascript
version: '3.8'

services:
  # Node.js API
  api:
    build: .
    ports:
      - "3000:3000"
    environment:
      - NODE_ENV=production
      - MONGO_URI=mongodb://mongo:27017/mydb
      - REDIS_URL=redis://redis:6379
    depends_on:
      - mongo
      - redis
    restart: unless-stopped

  # MongoDB
  mongo:
    image: mongo:7
    ports:
      - "27017:27017"
    volumes:
      - mongo-data:/data/db
    restart: unless-stopped

  # Redis Cache
  redis:
    image: redis:7-alpine
    ports:
      - "6379:6379"
    restart: unless-stopped

volumes:
  mongo-data:
```

          ### ⚡ คำสั่ง Docker Compose

          ```javascript
# เริ่มทุก services
docker compose up -d

# ดู logs
docker compose logs -f api

# หยุดทั้งหมด
docker compose down

# หยุดและลบ volumes
docker compose down -v

# สร้างใหม่
docker compose up -d --build
```
