# หน่วยที่ 1: พื้นฐาน Back-End
## บทเรียนย่อย: HTTP และ REST API

### 🔄 HTTP Protocol คืออะไร?

          HTTP (HyperText Transfer Protocol) คือโปรโตคอลที่ใช้ในการสื่อสารระหว่าง Client และ Server บนอินเทอร์เน็ต

          ### 📨 HTTP Methods

          

            - `GET` — ดึงข้อมูล (Read)

            - `POST` — สร้างข้อมูลใหม่ (Create)

            - `PUT/PATCH` — อัปเดตข้อมูล (Update)

            - `DELETE` — ลบข้อมูล (Delete)

          

          ### 📡 REST API Design

          ```javascript
GET    /users          → ดูผู้ใช้ทั้งหมด
GET    /users/:id      → ดูผู้ใช้คนเดียว
POST   /users          → สร้างผู้ใช้ใหม่
PUT    /users/:id      → อัปเดตข้อมูลผู้ใช้
DELETE /users/:id      → ลบผู้ใช้
```

          ### 📬 HTTP Status Codes

          

            - `200 OK` — สำเร็จ

            - `201 Created` — สร้างสำเร็จ

            - `400 Bad Request` — ข้อมูลไม่ถูกต้อง

            - `401 Unauthorized` — ไม่ได้รับอนุญาต

            - `404 Not Found` — ไม่พบข้อมูล

            - `500 Internal Server Error` — Server มีปัญหา
