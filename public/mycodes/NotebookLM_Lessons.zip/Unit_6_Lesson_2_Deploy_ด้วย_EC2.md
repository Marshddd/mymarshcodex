# หน่วยที่ 6: Cloud Deployment (AWS)
## บทเรียนย่อย: Deploy ด้วย EC2

### 🖥️ สร้าง EC2 Instance

          EC2 (Elastic Compute Cloud) คือบริการ Virtual Server ใน AWS

          ### 📋 ขั้นตอนการ Deploy

          ```javascript
# 1. SSH เข้า EC2
ssh -i "my-key.pem" ec2-user@ec2-xxx.amazonaws.com

# 2. ติดตั้ง Node.js
curl -fsSL https://rpm.nodesource.com/setup_20.x | sudo bash -
sudo yum install -y nodejs

# 3. ติดตั้ง PM2 (Process Manager)
sudo npm install -g pm2

# 4. Clone โปรเจค
git clone https://github.com/user/my-api.git
cd my-api

# 5. ติดตั้ง dependencies
npm ci --production

# 6. รัน ด้วย PM2
pm2 start server.js --name "my-api"
pm2 save
pm2 startup
```

          ### 🌐 Nginx Reverse Proxy

          ```javascript
# /etc/nginx/conf.d/myapp.conf
server {
    listen 80;
    server_name api.example.com;

    location / {
        proxy_pass http://localhost:3000;
        proxy_http_version 1.1;
        proxy_set_header Upgrade $http_upgrade;
        proxy_set_header Connection 'upgrade';
        proxy_set_header Host $host;
        proxy_cache_bypass $http_upgrade;
    }
}
```

          ### 🔒 SSL Certificate

          ```javascript
# ใช้ Let's Encrypt (ฟรี)
sudo yum install certbot python3-certbot-nginx
sudo certbot --nginx -d api.example.com
```
