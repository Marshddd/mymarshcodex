# หน่วยที่ 3: ฐานข้อมูลด้วย MongoDB
## บทเรียนย่อย: รู้จักกับ MongoDB

### 🍃 MongoDB คืออะไร?

          MongoDB คือ NoSQL Database ที่เก็บข้อมูลในรูปแบบ Document (JSON-like) แทนที่จะเป็น Table แบบ SQL

          ### 📊 เปรียบเทียบ SQL vs MongoDB

          

            - SQL: `Table` → MongoDB: `Collection`

            - SQL: `Row` → MongoDB: `Document`

            - SQL: `Column` → MongoDB: `Field`

          

          ### 🔌 เชื่อมต่อกับ Mongoose

          ```
`npm install mongoose`
```

          ```javascript
const mongoose = require('mongoose');

mongoose.connect('mongodb://localhost:27017/mydb')
  .then(() => console.log('✅ MongoDB connected'))
  .catch(err => console.error(err));
```

          ### 📋 Schema และ Model

          ```javascript
const userSchema = new mongoose.Schema({
  name: { type: String, required: true },
  email: { type: String, required: true, unique: true },
  password: String,
  createdAt: { type: Date, default: Date.now }
});

const User = mongoose.model('User', userSchema);
```
