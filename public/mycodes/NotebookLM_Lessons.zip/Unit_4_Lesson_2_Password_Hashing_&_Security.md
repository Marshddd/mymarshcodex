# หน่วยที่ 4: Authentication & JWT
## บทเรียนย่อย: Password Hashing & Security

### 🔒 ทำไมต้อง Hash รหัสผ่าน?

          การเก็บรหัสผ่านแบบ plain text อันตรายมาก ถ้าข้อมูลรั่วไหล ผู้ใช้ทุกคนจะถูกเข้าถึงได้ทันที

          ### 🧂 bcrypt กับ Salt

          ```javascript
const bcrypt = require('bcryptjs');

// Hash password พร้อม salt rounds
const salt = await bcrypt.genSalt(12);
const hashedPassword = await bcrypt.hash('mypassword', salt);

// ตรวจสอบ password
const isMatch = await bcrypt.compare('mypassword', hashedPassword);
// isMatch = true
```

          ### 🛡️ Security Best Practices

          

            - ไม่เก็บ password แบบ plain text

            - ใช้ `salt rounds` ≥ 10

            - ใช้ HTTPS เสมอ

            - กำหนด `expiresIn` ให้ token

            - ใช้ `httpOnly` cookie สำหรับ token

            - เก็บ secret ใน environment variables

          

          ### 🔐 Helmet — HTTP Security Headers

          ```javascript
const helmet = require('helmet');
app.use(helmet());

// ป้องกัน:
// - XSS attacks
// - Clickjacking
// - MIME sniffing
// - และอื่นๆ
```

          ### 📝 Rate Limiting

          ```javascript
const rateLimit = require('express-rate-limit');

const limiter = rateLimit({
  windowMs: 15 * 60 * 1000, // 15 นาที
  max: 100 // จำกัด 100 requests ต่อ IP
});

app.use('/api/', limiter);
```
