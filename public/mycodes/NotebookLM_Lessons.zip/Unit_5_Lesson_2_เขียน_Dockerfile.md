# หน่วยที่ 5: Docker & Containerization
## บทเรียนย่อย: เขียน Dockerfile

### 📄 Dockerfile คืออะไร?

          Dockerfile คือไฟล์ที่กำหนดขั้นตอนการสร้าง Docker Image — เหมือน recipe สำหรับการเตรียมสภาพแวดล้อม

          ### 🛠️ Dockerfile สำหรับ Node.js

          ```javascript
# ใช้ Node.js image เป็นฐาน
FROM node:20-alpine

# กำหนด working directory
WORKDIR /app

# คัดลอก package files ก่อน (สำหรับ caching)
COPY package*.json ./

# ติดตั้ง dependencies
RUN npm ci --only=production

# คัดลอกโค้ดทั้งหมด
COPY . .

# เปิด port
EXPOSE 3000

# คำสั่งรัน
CMD ["node", "server.js"]
```

          ### 🚫 .dockerignore

          ```javascript
node_modules
npm-debug.log
.git
.env
Dockerfile
docker-compose.yml
README.md
```

          ### 🏗️ Build และ Run

          ```javascript
# Build image
docker build -t my-api:1.0 .

# รันจาก image ที่สร้าง
docker run -d -p 3000:3000 \
  --name my-api \
  -e NODE_ENV=production \
  my-api:1.0
```

          ### 🔍 Multi-stage Build

          ```javascript
# Stage 1: Build
FROM node:20 AS builder
WORKDIR /app
COPY package*.json ./
RUN npm ci
COPY . .
RUN npm run build

# Stage 2: Production
FROM node:20-alpine
WORKDIR /app
COPY --from=builder /app/dist ./dist
COPY package*.json ./
RUN npm ci --only=production
EXPOSE 3000
CMD ["node", "dist/server.js"]
```
