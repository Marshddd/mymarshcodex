# หน่วยที่ 1: พื้นฐาน Back-End
## บทเรียนย่อย: Back-End คืออะไร?

### 🌐 Back-End Development คืออะไร?

          Back-End คือส่วนของระบบที่ทำงานอยู่เบื้องหลัง ผู้ใช้งานทั่วไปมองไม่เห็น แต่เป็นส่วนสำคัญที่ทำให้แอปพลิเคชันทำงานได้

          

            - **Server:** คอมพิวเตอร์หรือโปรแกรมที่รับและตอบสนองต่อ request

            - **Database:** ที่จัดเก็บข้อมูลทั้งหมดของระบบ

            - **API:** ช่องทางสื่อสารระหว่าง Front-End และ Back-End

          

          ### ⚙️ หน้าที่ของ Back-End Developer

          Back-End Developer รับผิดชอบในการสร้างและดูแลระบบต่างๆ ดังนี้:

          

            - ออกแบบและพัฒนา API

            - จัดการฐานข้อมูล

            - ดูแลความปลอดภัยของระบบ

            - เพิ่มประสิทธิภาพการทำงานของ Server

          

          ### 📊 Stack ที่ใช้ในคอร์สนี้

          ```javascript
Node.js (Runtime)
Express.js (Web Framework)
MongoDB (Database)
Docker (Container)
AWS (Cloud Platform)
```
