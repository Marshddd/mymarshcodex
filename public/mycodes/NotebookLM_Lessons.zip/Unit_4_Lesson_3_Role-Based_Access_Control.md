# หน่วยที่ 4: Authentication & JWT
## บทเรียนย่อย: Role-Based Access Control

### 👥 RBAC คืออะไร?

          Role-Based Access Control (RBAC) คือการจำกัดสิทธิ์การเข้าถึงตาม role ของผู้ใช้

          ### 🏷️ ตัวอย่าง Roles

          ```javascript
const ROLES = {
  USER: 'user',
  ADMIN: 'admin',
  MODERATOR: 'moderator'
};

const userSchema = new mongoose.Schema({
  username: String,
  password: String,
  role: {
    type: String,
    enum: Object.values(ROLES),
    default: ROLES.USER
  }
});
```

          ### 🔒 Authorization Middleware

          ```javascript
const authorize = (...roles) => {
  return (req, res, next) => {
    if (!roles.includes(req.user.role)) {
      return res.status(403).json({
        error: 'ไม่มีสิทธิ์เข้าถึง'
      });
    }
    next();
  };
};

// ใช้งาน
app.delete('/users/:id',
  authMiddleware,
  authorize('admin'),
  deleteUser
);

app.put('/posts/:id',
  authMiddleware,
  authorize('admin', 'moderator'),
  updatePost
);
```

          ### 📋 Permissions Matrix

          ```javascript
const permissions = {
  user:      ['read:own', 'update:own'],
  moderator: ['read:any', 'update:any', 'delete:own'],
  admin:     ['read:any', 'create:any', 'update:any', 'delete:any']
};
```
