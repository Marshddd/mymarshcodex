# หน่วยที่ 2: Node.js และ Express
## บทเรียนย่อย: Error Handling และ Validation

### ⚠️ Error Handling ใน Express

          การจัดการ Error ที่ดีจะทำให้ระบบมีความเสถียรและง่ายต่อการ debug

          ```javascript
// Global Error Handler
app.use((err, req, res, next) => {
  console.error(err.stack);
  res.status(err.status || 500).json({
    error: {
      message: err.message,
      status: err.status || 500
    }
  });
});
```

          ### 📝 Custom Error Class

          ```javascript
class AppError extends Error {
  constructor(message, status) {
    super(message);
    this.status = status;
  }
}

// ใช้งาน
app.get('/user/:id', (req, res, next) => {
  const user = users.find(u => u.id === req.params.id);
  if (!user) {
    return next(new AppError('ไม่พบผู้ใช้', 404));
  }
  res.json(user);
});
```

          ### ✅ Input Validation

          ```javascript
// ตรวจสอบข้อมูลก่อนบันทึก
app.post('/users', (req, res) => {
  const { name, email, password } = req.body;
  
  const errors = [];
  if (!name) errors.push('กรุณาระบุชื่อ');
  if (!email) errors.push('กรุณาระบุอีเมล');
  if (!password || password.length  0) {
    return res.status(400).json({ errors });
  }
  
  // บันทึกข้อมูล...
});
```
